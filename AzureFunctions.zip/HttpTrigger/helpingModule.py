def new_data_test():
    new_result = "Dipak"
    return new_result